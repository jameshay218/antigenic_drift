20150526
A new simplified version is created for simulating influenza binding avidity evolution.
The package is a clean version and contains only minimum sets of codes to run simulation.